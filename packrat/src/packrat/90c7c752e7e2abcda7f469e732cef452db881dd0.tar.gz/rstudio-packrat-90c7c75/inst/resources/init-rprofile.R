#### -- Packrat Autoloader (version 0.5.0-1) -- ####
source("packrat/init.R")
#### -- End Packrat Autoloader -- ####
