.onLoad <- function(libname, pkgname) {
  options(broom.mixed.sep1 = "__")
}
