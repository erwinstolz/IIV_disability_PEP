library(testthat)
library(merTools)


test_check("merTools", filter = "^[n-z]")
